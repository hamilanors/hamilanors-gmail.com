<?PHP
$Page="Index";
header("location:$Page");
?>

