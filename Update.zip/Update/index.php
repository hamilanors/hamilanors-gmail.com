<?
$src="index";
header("location:$src");
?>
